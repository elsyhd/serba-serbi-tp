# NIM/Nama : 16922096/Nabila Syahidah
# Tanggal : 16/09/2022
# Deskripsi : Program untuk menentukan durasi berlari Tuan Riz

#kamus
#jamMulai, menitMulai, detikMulai, jamSelesai, menitSelesai, detikSelesai [tipe: integer]

#buat user input untuk setiap variabel
print('masukkan waktu mulai!')
jamMulai = int(input('Jam:'))
menitMulai = int(input('Menit:'))
detikMulai = int(input('Detik:'))

print('masukkan waktu selesai!')
jamSelesai = int(input('Jam:'))
menitSelesai = int(input('Menit:'))
detikSelesai = int(input('Detik:'))

#lakukan perhitungan
jam = jamSelesai-jamMulai
menit = menitSelesai-menitMulai
detik = detikSelesai-detikMulai

if detik < 0:
    menit = menit - 1
    detik = detik + 60
if menit < 0:
    jam = jam - 1
    menit = menit + 60

#buat output untuk setiap case
if jam > 0 and menit > 0 and detik > 0:
    print('Tuan Riz berlari selama', str(jam), 'jam', str(menit), 'menit', str(detik), 'detik')
if jam == 0 and menit > 0 and detik > 0:
    print('Tuan Riz berlari selama', str(menit), 'menit', str(detik), 'detik')
if jam == 0 and menit == 0 and detik > 0:
    print('Tuan Riz berlari selama', str(detik), 'detik')
if jam > 0 and menit == 0 and detik > 0:
    print('Tuan Riz berlari selama', str(jam), 'jam', str(detik), 'detik')
if jam > 0 and menit == 0 and detik == 0:
    print('Tuan Riz berlari selama', str(jam), 'jam')
if jam > 0 and menit > 0 and detik == 0:
    print('Tuan Riz berlari selama', str(jam), 'jam', str(menit), 'menit')
if jam == 0 and menit == 0:
    print('Tuan Riz berlari selama', str(detik), 'detik')
