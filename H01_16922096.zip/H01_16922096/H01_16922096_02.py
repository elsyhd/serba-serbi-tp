# NIM/Nama : 16922096/Nabila Syahidah
# Tanggal : 16/09/2022
# Deskripsi : Program untuk menentukan kelas berdasarkan NIM

#kamus
#akhiranNIM[tipe: integer]

#buat user input 
akhiranNIM = int(input('masukkan akhiran NIM:'))
if not type(akhiranNIM) is int:
    raise TypeError("input hanya bisa angka")

if akhiranNIM >= 1 and akhiranNIM <= 100 :
    a = akhiranNIM % 2
    if a == 0 :
        print('Mahasiswa masuk ke kelas K2')
    else :
        print('Mahasiswa masuk ke kelas K1')
if akhiranNIM >= 101 and akhiranNIM <= 200 :
    b = akhiranNIM % 2
    if b == 0 :
        print('Mahasiswa masuk ke kelas K4')
    else :
        print('Mahasiswa masuk ke kelas K3')
if akhiranNIM >= 201 and akhiranNIM <= 300 :
    c = akhiranNIM % 2
    if c == 0 :
        print('Mahasiswa masuk ke kelas K6')
    else :
        print('Mahasiswa masuk ke kelas K5')
if akhiranNIM > 300 :
    d = akhiranNIM % 2
    if d == 0 :
        print('Mahasiswa masuk ke kelas K8')
    else :
        print('Mahasiswa masuk ke kelas K7')