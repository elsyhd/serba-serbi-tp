# NIM/Nama : 16922096/Nabila Syahidah
# Tanggal : 16/09/2022
# Deskripsi : Program untuk menentukan barang dengan laba terbanyak

#kamus
#hargaDasarA, hargaDasarB, hargaDasarC, hargaJualA, hargaJualB, hargaJualC [tipe: integer]

#buat user input untuk setiap variabel
hargaDasarA =int(input('masukkan harga dasar barang A:'))
if not type(hargaDasarA) is int:
    raise TypeError("input hanya bisa angka")
    
hargaJualA =int(input('masukkan harga jual barang A:'))
if not type(hargaJualA) is int:
    raise TypeError("input hanya bisa angka")
A = hargaJualA - hargaDasarA

hargaDasarB =int(input('masukkan harga dasar barang B:'))
if not type(hargaDasarB) is int:
    raise TypeError("input hanya bisa angka")
    
hargaJualB =int(input('masukkan harga jual barang B:'))
if not type(hargaJualB) is int:
    raise TypeError("input hanya bisa angka")
B = hargaJualB - hargaDasarB

hargaDasarC =int(input('masukkan harga dasar barang C:'))
if not type(hargaDasarC) is int:
    raise TypeError("input hanya bisa angka")
    
hargaJualC =int(input('masukkan harga jual barang C:'))
if not type(hargaJualC) is int:
    raise TypeError("input hanya bisa angka!")
C = hargaJualC - hargaDasarC

#tentukan barang dengan laba terbanyak
barangTercuan = max(A,B,C)

#buat output untuk setiap case
if barangTercuan == A :
    print('barang yang harus ditawarkan adalah barang A')
if barangTercuan == B :
    print('barang yang harus ditawarkan adalah barang B')
if barangTercuan == C :
    print('barang yang harus ditawarkan adalah barang C')